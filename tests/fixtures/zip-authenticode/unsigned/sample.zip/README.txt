psign ZIP Authenticode fixture
